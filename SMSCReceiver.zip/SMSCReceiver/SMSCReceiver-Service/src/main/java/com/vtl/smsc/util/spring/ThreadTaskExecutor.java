package com.vtl.smsc.util.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.scheduling.backportconcurrent.ThreadPoolTaskExecutor;

public class ThreadTaskExecutor
{
	private static ThreadPoolTaskExecutor Exec;
	private static ThreadTaskExecutor Executer= null;
	
	private ThreadTaskExecutor()
	{
	
	}
	public static ThreadTaskExecutor getInstance()
	{
		if (Executer == null)
		{
			synchronized (ThreadTaskExecutor.class)
			{
				if (Executer == null) 
				{
					Executer = new ThreadTaskExecutor();
					initializePool();
				}
			}
		}
		return Executer;
	}
	//-------------
	private static void initializePool()
	{
		//Executor,Exec
		Exec=(ThreadPoolTaskExecutor)SmscReceiverContextFactory.getInstance().getBean("Executor");
	}
	//-----------------
	public static ThreadPoolTaskExecutor getPool()
	{
		return Exec;
		
	}
}
