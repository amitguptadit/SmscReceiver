
/**
 * @author @mit.gupta
 * @version 1.0
 * 
 */
package com.vtl.smsc.invoker;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.vtl.smsc.config.FileConfig;
import com.vtl.smsc.exceptions.BusinessException;
import com.vtl.smsc.util.ResponseConstants;
import com.vtl.smsc.util.spring.CustomBeanProvider;

public class InvokerSmscReceiver 
{

	
	public static final Logger logger = Logger.getLogger("InvokerSmscReceiver.class");
	
		
	private FileConfig fileConfig;
	
	public FileConfig getFileConfig() {
		return fileConfig;
	}
	public void setFileConfig(FileConfig fileConfig) {
		this.fileConfig = fileConfig;
	}
		//----------------[	main() Method ]-----------
		public static void main(String[] args) throws BusinessException
		{	
			/*DOMConfigurator.configure("D:\\AmitData\\VideoconProjectData\\WorkSpace\\vtl_workspace\\SMSCReceiver\\SMSCReceiver-Service\\src\\main\\resources\\log4j.xml");
			BasicConfigurator.configure();
			*/
			logger.debug("[ we are in InvokerSmscReceiver ]");

			InvokerSmscReceiver invoker=new InvokerSmscReceiver();
			invoker.prepareApplicationContext();			
			
			
			if (CustomBeanProvider.getSpringContext() == null) 
			{
				
				logger.error("ApplicationContext is not instantiated yet.");
				
			}
			else 
			{				
				logger.info("ApplicationContext instantiation is done. . .");						
				System.out.println("[	ApplicationContext instantiation is done. . .	]");
			}		
			
		}//End of main Method
		//---------------[	prepareApplicationContext()	]-----------
		/**
		 * This method is used to load the spring application context
		 */
		public void prepareApplicationContext() throws BusinessException
		{
			try
			{
				
				ApplicationContext ctx = new ClassPathXmlApplicationContext("context-scheduler.xml");
				CustomBeanProvider.setSpringContext(ctx);
				
			} 
			catch (Exception e)
			{
				
				logger.error("Error While instantiating Application Context: ", e);
				throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
			}
		}//--End prepareApplicationContext()
		//---------
		
}//End of class
