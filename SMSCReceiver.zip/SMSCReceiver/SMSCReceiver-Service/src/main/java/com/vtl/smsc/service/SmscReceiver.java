/**
 * @author @mit.gupta
 * @version 1.0
 * 
 */

package com.vtl.smsc.service;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.apache.log4j.Logger;
import com.vtl.smsc.SmscProcess;
import com.vtl.smsc.config.FileConfig;
import com.vtl.smsc.exceptions.BusinessException;
import com.vtl.smsc.pojo.SmppConfig;
import com.vtl.smsc.service.impl.SmscReceiverImpl;
import com.vtl.smsc.util.ResponseConstants;
import java.io.PrintWriter;
import java.io.StringWriter;

public class SmscReceiver implements SmscReceiverImpl
{
	public static final Logger logger = Logger.getLogger(SmscReceiver.class);
	
	
	private static SmppConfig smppConfig;	
	private static SmscProcess SmscMain;
	
	public static String propFile;
	
	private FileConfig fileConfig;

	private static String smsIP;
	private static String smsPort;

	private ThreadPoolTaskExecutor taskExecutor;
	
	
	
	public ThreadPoolTaskExecutor getTaskExecutor() {
		return taskExecutor;
	}

	public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
		this.taskExecutor = taskExecutor;
	}

	public FileConfig getFileConfig() {
		return fileConfig;
	}

	public void setFileConfig(FileConfig fileConfig)
	{
		this.fileConfig = fileConfig;
	}
	//-----------[	initBean()	]-------
	@Override
	public  void initBean() throws BusinessException
	{		
		
		
		try
		{
			 
			 
			 propFile =fileConfig.getLocalFilePath();
			 //27-oct2015
			java.io.FileInputStream pin = new java.io.FileInputStream(propFile+"app.conf");
			java.util.Properties props = new java.util.Properties();
			props.load(pin);
			
			
			
			try 
			{
					//--------------Starting the applications Thread--
					//27-oct2015				
					smppConfig = loadSmppCong();
					SmscMain.SmscLoad(propFile,smppConfig);		
					//***************[ 23oct2015	]********************
					taskExecutor.execute(new PDUThreadHandler(smppConfig,SmscMain));
					taskExecutor.execute(new enquireReceiverLinkThread(smppConfig, SmscMain));
					taskExecutor.execute(new ThreadHandler());
					//********************************
					//---------End of applications Thread---------
			} 
			
			catch (Exception e)
			{
				logger.error(e.getMessage(), e);
				throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
			}

		}
		/*catch(FileNotFoundException e)
		{
			throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
		}*/
		catch(Exception e)
		{
			throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);	
		}
		
	}
		//---------------[	Implementing Threads	]----------------
	
		public class ThreadHandler implements Runnable {

		public void run() {
			try {
					if (SmscMain != null)
					{
						try 
						{
							while (true) 
							{								
								SmscMain.receive(smppConfig);
							}
						} 
						catch (Exception e)
						{						
							StringWriter stack = new StringWriter();
							PrintWriter writer = new PrintWriter(stack);
							e.printStackTrace(writer);
							logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
							+ ":"+stack.toString());
							
							throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
							
						}
					}
			} 
			catch (Exception e)
			{
				StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());				
			}
		}
		
	}
		//----------------[	End of Implementing Thread	]------------
		//------------[	loadSmppCong()	]-----------
		@Override
		public  SmppConfig loadSmppCong() throws BusinessException
		{ 
			try
			{
				//propFile = configPath+"smppchn.conf";
				java.io.FileInputStream pin = new java.io.FileInputStream(propFile+"smppchn.conf");
	            java.util.Properties pr = new java.util.Properties();
	            pr.load(pin);

				SmppConfig smppConf = new SmppConfig();
				smppConf.setHost(pr.getProperty("sms.receiver.ip"));
				smppConf.setSmppport(pr.getProperty("sms.receiver.port"));
				smppConf.setTimeout(pr.getProperty("sms.timeout"));
				smppConf.setSleeptime(pr.getProperty("sms.enquire.time"));
				smppConf.setSmsKeyword(pr.getProperty("sms-keyword"));
				smppConf.setGprsKeyword(pr.getProperty("gprs-keyword"));
				smppConf.setMmsKeyword(pr.getProperty("mms-keyword"));
				smppConf.setVtlSMSPassword(pr.getProperty("vtl-smspassd"));
				smppConf.setVtlSIMPassword(pr.getProperty("vtl-simpassd"));
				smppConf.setLoadBalancerUrl(pr.getProperty("loadbalancer-url"));
				smppConf.setValidMsgReply(pr.getProperty("valid-msg-reply"));
				smppConf.setInvalidMsgReply(pr.getProperty("invalid-msg-reply"));
				smppConf.setSourceAddress(pr.getProperty("source-address"));
				smppConf.setLyesKeyword(pr.getProperty("lyes-keyword"));
				smppConf.setLoanKeyword(pr.getProperty("loan-keyword"));
				smppConf.setNbfLoadBalancerUrl(pr.getProperty("nbfloadbalancer-url"));
				return smppConf;
			}
			catch (Exception e)
			{
				StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
				return null;
			}

		}
	public static SmppConfig getSmppConfig() {
		return smppConfig;
	}

	public static void setSmppConfig(SmppConfig smppConfig) {
		SmscReceiver.smppConfig = smppConfig;
	}
	
	public static SmscProcess getSmscMain() {
		return SmscMain;
	}

	public static void setSmscMain(SmscProcess smscMain) {
		SmscMain = smscMain;
	}

	public static String getPropFile() {
		return propFile;
	}

	public static void setPropFile(String propFile) {
		SmscReceiver.propFile = propFile;
	}

	public static String getSmsIP() 
	{
		return smsIP;
	}

	public static void setSmsIP(String smsIP) {
		SmscReceiver.smsIP = smsIP;
	}

	public static String getSmsPort() {
		return smsPort;
	}

	public static void setSmsPort(String smsPort) {
		SmscReceiver.smsPort = smsPort;
	}

}//End of class SmscReceiver

//----[	enquireReceiverLinkThread class	]--------
class enquireReceiverLinkThread implements Runnable
{
	String requestString;
	int timeout;
	PrintWriter out;
	String transID;
	String key;
	SmppConfig smscConfig;
	SmscProcess SmscMain;

		
	enquireReceiverLinkThread(SmppConfig smscConfig, SmscProcess _SmscMain)
	{
		this.smscConfig = smscConfig;
		this.SmscMain = _SmscMain;
	}

	public void run()
	{
		if (smscConfig != null && smscConfig.getSleeptime() != null
				&& !smscConfig.getSleeptime().isEmpty())
				{
					timeout = Integer.parseInt(smscConfig.getSleeptime());
				}

		while (true)
		{
			try
			{
				if (!SmscMain.enquireLink(timeout))
				{
					SmscMain.kill();
					SmscMain.bind();
					if (!SmscMain.enquireLink())
					{
						System.exit(0);
					}
				}

			}
			catch (Exception e)
			{

				StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				SmscReceiver.logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
			}
		}//End of while

	}//End of run
}//End of enquireReceiverLinkThread
//--------[	PDUThreadHandler class	]------------- 
class PDUThreadHandler implements Runnable
{
	String requestString;
	long timeout;
	PrintWriter out;
	String transID;
	String key;
	SmppConfig smscConfig;
	SmscProcess SmscMain;

	
	
	PDUThreadHandler(SmppConfig smscConfig, SmscProcess _SmscMain) 
	{		
		
		this.smscConfig = smscConfig;
		this.SmscMain = _SmscMain;
	}

	public void run()
	{
		try
		{
			SmscMain.checkPDU();
		}
		catch(Exception e)
		{
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			SmscReceiver.logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
			+ ":"+stack.toString());
		}
	}//End of run()
}
