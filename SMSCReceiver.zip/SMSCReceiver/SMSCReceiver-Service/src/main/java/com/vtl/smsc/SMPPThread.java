package com.vtl.smsc;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;

import org.smpp.ServerPDUEvent;
import org.smpp.pdu.DeliverSM;
import org.smpp.pdu.PDU;
import org.smpp.pdu.PDUHeader;
import org.smpp.pdu.Request;

import com.vtl.smsc.pojo.SmppConfig;
import com.vtl.smsc.util.ResponseConstants;

public class SMPPThread implements Runnable {
	public static Logger logger = Logger.getLogger(SMPPThread.class);

	ServerPDUEvent pduEvent = null;
	PDU pdu = null;
	PDUHeader ph = null;

	SmppConfig cfg = null;

	SMPPThread(ServerPDUEvent pdu, SmppConfig cfg1) {
		pduEvent = pdu;
		cfg = cfg1;
	}

	public void run() 
	{
		try {
			if (pduEvent != null) 
			{
				pdu = pduEvent.getPDU();
			}

			if (pdu != null) 
			{
				
				String msgRec = new String(pdu.getBody().getBuffer()).trim();

				//pdu.getBody()=ByteBuffer
				//pdu.getBody().getBuffer()=byte[] of buffer
				//pdu.get
				//pdu.getBody().getBuffer()
				logger.info(pdu.debugString() + "Received PDU:: |" + msgRec
						+ "|" + pdu.getData().toString() + "|"
						+ pdu.getBody().getBuffer());

				if (pdu.isRequest()) 
				{

					org.smpp.pdu.Response response = ((Request) pdu)
							.getResponse();
					DeliverSM ds = ((DeliverSM) pdu);
					String sourceno = ds.getSourceAddr().getAddress();
					String shortmessage = ds.getShortMessage();

					logger.info("shortmessage = " + shortmessage);
					logger.info("Source Number:" + sourceno);

					logger.info("Going to send default response to request "
							+ response.debugString());

					SmscProcess.session.respond(response);
					String res = null;
					msgRec = shortmessage;

					if ((sourceno != null && !sourceno.isEmpty())
							&& (msgRec != null && !msgRec.isEmpty()))
					{
						logger.info("sourceno = " + sourceno);
						logger.info("msgRec = " + msgRec);
						SMSCHandler smsHandler = new SMSCHandler(cfg, msgRec,sourceno);
						res = smsHandler.handleSMS();
						logger.info("response received after calling the LoadBalancer");
					} 
					else
					{
						logger.info("Source Number or Short Message not Found");
					}

				} 
				else
				{
					logger.info("PDU Is not isRequest()");
				}
			} 
			else
			{
				logger.info("No PDU received this time.");
			}
		} 
		catch (Exception e)
		{
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
			+ ":"+stack.toString());
		}
	}//End of run()
}
