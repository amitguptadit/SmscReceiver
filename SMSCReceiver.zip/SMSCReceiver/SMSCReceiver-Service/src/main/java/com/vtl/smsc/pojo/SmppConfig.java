package com.vtl.smsc.pojo;

import java.io.PrintWriter;
import java.net.Socket;

public class SmppConfig {

	private String sourceAddress;

	private String moderatorport;
	private String vendorcode;
	private String message;
	private String instancename;
	private String logsize;
	public String validatorClass;
	private String host;
	private String corehost;
	private String coreport;
	private String corehost1;
	private String coreport1;
	private PrintWriter messagewriter;
	private String pingserver;
	public String validatorType;
	private String transID;
	private String timeout;
	private int port;
	private String smppport;
	private int pool;
	private int poolbuffer;
	private String sleeptime;
	private String sendInvalidSMS;
	private String smsContent;
	private String sendersmpphost;
	private String sendersmppport;
	private String failureSMS;
	private String smsKeyword;
	private String gprsKeyword;
	private String mmsKeyword;
	private String vtlSMSPassword;
	private String vtlSIMPassword;
	private String loadBalancerUrl;
	private String validMsgReply;
	private String invalidMsgReply;
	private String loanKeyword;
	private String lyesKeyword;
	private String nbfLoadBalancerUrl;

	public Socket clientSocket;

	public String getInstancename() {
		return instancename;
	}

	public void setInstancename(String instancename) {
		this.instancename = instancename;
	}

	public String getLogsize() {
		return logsize;
	}

	public void setLogsize(String logsize) {
		this.logsize = logsize;
	}

	public String getPingserver() {
		return pingserver;
	}

	public void setPingserver(String pingserver) {
		this.pingserver = pingserver;
	}

	public Socket getClientSocket() {
		return clientSocket;
	}

	public void setClientSocket(Socket clientSocket) {
		this.clientSocket = clientSocket;
	}

	public String getValidatorClass() {
		return validatorClass;
	}

	public void setValidatorClass(String validatorClass) {
		this.validatorClass = validatorClass;
	}

	public String getValidatorType() {
		return validatorType;
	}

	public void setValidatorType(String validatorType) {
		this.validatorType = validatorType;
	}

	public String getTransID() {
		return transID;
	}

	public void setTransID(String transID) {
		this.transID = transID;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getModeratorport() {
		return moderatorport;
	}

	public void setModeratorport(String moderatorport) {
		this.moderatorport = moderatorport;
	}

	public PrintWriter getMessagewriter() {
		return messagewriter;
	}

	public void setMessagewriter(PrintWriter messagewriter) {
		this.messagewriter = messagewriter;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getCoreport() {
		return coreport;
	}

	public void setCoreport(String coreport) {
		this.coreport = coreport;
	}

	public String getCoreport1() {
		return coreport1;
	}

	public void setCoreport1(String coreport) {
		this.coreport1 = coreport;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getDefaultPort() {
		return this.getPort();
	}

	public String getDefaultHost() {
		return this.getHost();
	}

	public int getPool() {
		return pool;
	}

	public void setPool(int pool) {
		this.pool = pool;
	}

	public int getPoolbuffer() {
		return poolbuffer;
	}

	public void setPoolbuffer(int poolbuffer) {
		this.poolbuffer = poolbuffer;
	}

	public String getRequestMessage() {

		return this.getMessage();
	}

	public void setRequestMessage(String msg) {
		this.setMessage(msg);
	}

	private Class getObject(String loadClassName) {
		try {
			return Class.forName(loadClassName);
		} catch (Exception ee) {
			ee.printStackTrace();
			return null;
		}
	}

	public String getVendorcode() {
		return vendorcode;
	}

	public void setVendorcode(String vendorcode) {
		this.vendorcode = vendorcode;
	}

	public String getTimeout() {
		return timeout;
	}

	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}

	public String getSmppport() {
		return smppport;
	}

	public void setSmppport(String smppport) {
		this.smppport = smppport;
	}

	public String getCorehost() {
		return corehost;
	}

	public void setCorehost(String corehost) {
		this.corehost = corehost;
	}

	public String getCorehost1() {
		return corehost1;
	}

	public void setCorehost1(String corehost) {
		this.corehost1 = corehost;
	}

	public String getSleeptime() {
		return sleeptime;
	}

	public void setSleeptime(String sleeptime) {
		this.sleeptime = sleeptime;
	}

	public String getSendInvalidSMS() {
		return sendInvalidSMS;
	}

	public void setSendInvalidSMS(String sendInvalidSMS) {
		this.sendInvalidSMS = sendInvalidSMS;
	}

	public String getSmsContent() {
		return smsContent;
	}

	public void setSmsContent(String smsContent) {
		this.smsContent = smsContent;
	}

	public String getSendersmpphost() {
		return sendersmpphost;
	}

	public void setSendersmpphost(String sendersmpphost) {
		this.sendersmpphost = sendersmpphost;
	}

	public String getSendersmppport() {
		return sendersmppport;
	}

	public void setSendersmppport(String sendersmppport) {
		this.sendersmppport = sendersmppport;
	}

	public String getFailureSMS() {
		return failureSMS;
	}

	public void setFailureSMS(String failureSMS) {
		this.failureSMS = failureSMS;
	}

	public String getSmsKeyword() {
		return smsKeyword;
	}

	public void setSmsKeyword(String smsKeyword) {
		this.smsKeyword = smsKeyword;
	}

	public String getGprsKeyword() {
		return gprsKeyword;
	}

	public void setGprsKeyword(String gprsKeyword) {
		this.gprsKeyword = gprsKeyword;
	}

	public String getMmsKeyword() {
		return mmsKeyword;
	}

	public void setMmsKeyword(String mmsKeyword) {
		this.mmsKeyword = mmsKeyword;
	}

	public String getVtlSMSPassword() {
		return vtlSMSPassword;
	}

	public void setVtlSMSPassword(String vtlSMSPassword) {
		this.vtlSMSPassword = vtlSMSPassword;
	}

	public String getVtlSIMPassword() {
		return vtlSIMPassword;
	}

	public void setVtlSIMPassword(String vtlSIMPassword) {
		this.vtlSIMPassword = vtlSIMPassword;
	}

	public String getLoadBalancerUrl() {
		return loadBalancerUrl;
	}

	public void setLoadBalancerUrl(String loadBalancerUrl) {
		this.loadBalancerUrl = loadBalancerUrl;
	}

	public String getValidMsgReply() {
		return validMsgReply;
	}

	public void setValidMsgReply(String validMsgReply) {
		this.validMsgReply = validMsgReply;
	}

	public String getInvalidMsgReply() {
		return invalidMsgReply;
	}

	public void setInvalidMsgReply(String invalidMsgReply) {
		this.invalidMsgReply = invalidMsgReply;
	}

	public String getSourceAddress() {
		return sourceAddress;
	}

	public void setSourceAddress(String sourceAddress) {
		this.sourceAddress = sourceAddress;
	}

	public String getLoanKeyword() {
		return loanKeyword;
	}

	public void setLoanKeyword(String loanKeyword) {
		this.loanKeyword = loanKeyword;
	}

	public String getLyesKeyword() {
		return lyesKeyword;
	}

	public void setLyesKeyword(String lyesKeyword) {
		this.lyesKeyword = lyesKeyword;
	}

	public String getNbfLoadBalancerUrl() {
		return nbfLoadBalancerUrl;
	}

	public void setNbfLoadBalancerUrl(String nbfLoadBalancerUrl) {
		this.nbfLoadBalancerUrl = nbfLoadBalancerUrl;
	}

}
