package com.vtl.smsc.util.spring;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SmscReceiverContextFactory
{
	private static ApplicationContext ctx;
	private static SmscReceiverContextFactory ctxFactory = null;
	private SmscReceiverContextFactory()
	{
	
	}
	public static SmscReceiverContextFactory getInstance()
	{
		if (ctxFactory == null)
		{
			synchronized (SmscReceiverContextFactory.class)
			{
				if (ctxFactory == null) 
				{
					ctxFactory = new SmscReceiverContextFactory();
					initializeContext();
				}
			}
		}
		return ctxFactory;
	}

	public Object getBean(String s) {
		Object bean = null;
		try {
			bean = ctx.getBean(s);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return bean;
	}

	private static void initializeContext()
	{
		ctx = new ClassPathXmlApplicationContext("context-scheduler.xml");
	}

	protected SmscReceiverContextFactory readResolve()
	{
		return getInstance();
	}
	

}//--End of class
