package com.vtl.smsc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;

import org.apache.log4j.Logger;

import org.smpp.pdu.SubmitSM;

import com.vtl.smsc.pojo.SmppConfig;
import com.vtl.smsc.util.ResponseConstants;

public class SMSCHandler {

	public static Logger logger = Logger.getLogger(SMSCHandler.class);
	static SmppConfig config = null;
	static String recMsg = null;
	static String msisdn = null;
	static String imsi = null;
	static String imei = null;
	static String iccid = null;

	public SMSCHandler(SmppConfig _config, String _recMsg, String _msisdn) 
	{
		config = _config;
		recMsg = _recMsg;
		msisdn = _msisdn;
	}

	public synchronized String handleSMS()
	{
		String result = null;
		String password = null;
		String userId = null;
		String loadbalancerURL = config.getLoadBalancerUrl();
		String finalURL = null;
		String replyMsg = null;
		boolean willReply = false;
		try {
					if (recMsg != null && !recMsg.isEmpty())
					{
						logger.info("inside handleSMS.recMsg.." + recMsg);
						if (recMsg.toUpperCase().equals(config.getSmsKeyword())) {
							userId = "VTLSMS";
							password = config.getVtlSMSPassword();
							String VTLSMSURL = "?userid=" + userId + "&password="
									+ password + "&msisdn=" + msisdn;
							finalURL = loadbalancerURL + VTLSMSURL;
							logger.info("finalURL.." + finalURL);
							replyMsg = config.getValidMsgReply();
						} else if (recMsg.toUpperCase().startsWith(
								config.getGprsKeyword())
								|| recMsg.toUpperCase().startsWith(
										config.getMmsKeyword())) {
							String params[] = recMsg.split(" ");
							imsi = params[2];
							iccid = params[3];
							imei = params[4];
							userId = "VTLSIM";
							password = config.getVtlSIMPassword();
							String VTLSIMURL = "?userid=" + userId + "&password="
									+ password + "&msisdn=" + msisdn + "&imei=" + imei
									+ "&imsi=" + imsi;
							finalURL = loadbalancerURL + VTLSIMURL;
							logger.info("finalURL.." + finalURL);
							replyMsg = config.getValidMsgReply();
		
						} else if (recMsg.equalsIgnoreCase(config.getLoanKeyword())
								|| recMsg.equalsIgnoreCase(config.getLyesKeyword())) {
							userId = "SMSUSER";
							String prefixAdd = "91";
					        if (msisdn.length() == 10) {
					            msisdn = prefixAdd + msisdn;
					        }
							String VTLLOANURL = "?userid=" + userId + "&msisdn="
									+ msisdn + "&imsi=" + "&act_code=" + "&text="
									+ recMsg;
							finalURL = config.getNbfLoadBalancerUrl() + VTLLOANURL;
							logger.info("finalURL.." + finalURL);
							replyMsg = config.getValidMsgReply();
						} else {
		
							willReply = true;
							replyMsg = config.getInvalidMsgReply();
							logger.info("Invalid Message Formate");
						}
						if (willReply) {
		
							SubmitSM msg = new SubmitSM();
							msg.setDestAddr(msisdn);
							msg.setShortMessage(replyMsg);
							msg.setSourceAddr((byte) 5, (byte) 0,
									config.getSourceAddress());
							try {
								SmscProcess.session.submit(msg);
								logger.info("Reply msg submitted ");
							} catch (Exception e) {
								logger.error("inside submit msg exception"
										+ e.getMessage());
							}
		
						}
		
						if (finalURL != null && !finalURL.isEmpty()) {
							logger.info("inside finalURL.." + finalURL);
							callURL(finalURL);
							result = "Successfully URL Called";
						}
					}

		} 
		catch (Exception e) 
		{
			
			logger.error("Error in handleSMS method :::" + e.getMessage());
			logger.error("Error in handleSMS method :::" + e.getMessage());
			
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
			+ ":"+stack.toString());
		}

		return result;
	}

	public static void callURL(String url)
	{
		String result = null;
		HttpURLConnection conn = null;
		InputStreamReader istream = null;
		URL desturl = null;
		// Send a GET request to the servlet
		try
		{
			logger.info("url is----> "+url);
			desturl = new URL(url);
			conn = (HttpURLConnection) desturl.openConnection();
			conn.setConnectTimeout(60 * 1000);
			conn.setReadTimeout(900 * 1000);
			conn.setRequestMethod("GET");
			istream = new InputStreamReader(conn.getInputStream());
			result = "SuccessSend";
			logger.info("Successfully Submitted to LB----> "+result);
		}
		catch (IOException ioExc) 
		{
			logger.error("IO Exception in sending Requested URL");
			InputStream es = conn.getErrorStream();
			if (es != null)
			{
				BufferedReader esReader = null;
				esReader = new BufferedReader(new InputStreamReader(es,
						Charset.forName("UTF-8")));
				try
				{
					while (esReader.ready() && esReader.readLine() != null) 
					{
					}
					logger.error("Issue in Reading Exception");
				} 
				catch (IOException e) 
				{
					logger.error("Exception in Reading Exception");
					
					
					StringWriter stack = new StringWriter();
					PrintWriter writer = new PrintWriter(stack);
					e.printStackTrace(writer);
					logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":"+stack.toString());
				}
				if (esReader != null)
				{
					try
					{
						esReader.close();
					} 
					catch (IOException e)
					{
						logger.error("Issue in closing Reading Input Stream ");
						
						StringWriter stack = new StringWriter();
						PrintWriter writer = new PrintWriter(stack);
						e.printStackTrace(writer);
						logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
						+ ":"+stack.toString());
					}
				}
			}
			result = "FailedIOException";
			ioExc.printStackTrace();
		} 
		catch (Exception e)
		{
			logger.info("Issue in URL Connection");
			InputStream es = conn.getErrorStream();
			if (es != null) {
				BufferedReader esReader = null;
				esReader = new BufferedReader(new InputStreamReader(es,
						Charset.forName("UTF-8")));
				try 
				{
					while (esReader.ready() && esReader.readLine() != null)
					{
					}
				} 
				catch (IOException ioexc)
				{
					StringWriter stack = new StringWriter();
					PrintWriter writer = new PrintWriter(stack);
					ioexc.printStackTrace(writer);
					logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":"+stack.toString());
					
				}
				if (esReader != null)
					
					try 
					{
						esReader.close();
					}
					catch (IOException exception)
					{
						
						StringWriter stack = new StringWriter();
						PrintWriter writer = new PrintWriter(stack);
						exception.printStackTrace(writer);
						logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
						+ ":"+stack.toString());
						
					}
			}
			result = "FailedException";
			
			
			StringWriter stack = new StringWriter();
			PrintWriter writer = new PrintWriter(stack);
			e.printStackTrace(writer);
			logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
			+ ":"+stack.toString());
		} 
		finally
		{
			if (istream != null) 
			{
				try 
				{
					logger.error("ListenerClient:SendGetRequest:: Finally Closing inputstream ");
					istream.close();
				}
				catch (IOException ex)
				{
					logger.error("ListenerClient:SendGetRequest: IOEXCEPTION Finally Closing inputstream");
					//ex.printStackTrace();
					
					StringWriter stack = new StringWriter();
					PrintWriter writer = new PrintWriter(stack);
					ex.printStackTrace(writer);
					logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":"+stack.toString());
				}
			}
			if (conn != null)
			{
				conn.disconnect();
			}
			logger.info("result is----> " + result +" For MSISDN :"+ msisdn);
		}

	}

}
