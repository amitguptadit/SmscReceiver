package com.vtl.smsc;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Properties;

import org.apache.log4j.Logger;

/*
 import com.logica.smpp.Connection;
import com.logica.smpp.Data;
import com.logica.smpp.ServerPDUEvent;
import com.logica.smpp.ServerPDUEventListener;
import com.logica.smpp.Session;
import com.logica.smpp.SmppObject;
import com.logica.smpp.TCPIPConnection;
import com.logica.smpp.pdu.Address;
import com.logica.smpp.pdu.AddressRange;
import com.logica.smpp.pdu.BindReceiver;
import com.logica.smpp.pdu.BindRequest;
import com.logica.smpp.pdu.BindResponse;
import com.logica.smpp.pdu.BindTransciever;
import com.logica.smpp.pdu.BindTransmitter;
import com.logica.smpp.pdu.CancelSM;
import com.logica.smpp.pdu.CancelSMResp;
import com.logica.smpp.pdu.DataSM;
import com.logica.smpp.pdu.DataSMResp;
import com.logica.smpp.pdu.DeliverSM;
import com.logica.smpp.pdu.DestinationAddress;
import com.logica.smpp.pdu.EnquireLink;
import com.logica.smpp.pdu.EnquireLinkResp;
import com.logica.smpp.pdu.PDU;
import com.logica.smpp.pdu.PDUHeader;
import com.logica.smpp.pdu.QuerySM;
import com.logica.smpp.pdu.QuerySMResp;
import com.logica.smpp.pdu.ReplaceSM;
import com.logica.smpp.pdu.ReplaceSMResp;
import com.logica.smpp.pdu.Request;
import com.logica.smpp.pdu.Response;
import com.logica.smpp.pdu.SubmitMultiSM;
import com.logica.smpp.pdu.SubmitMultiSMResp;
import com.logica.smpp.pdu.SubmitSM;
import com.logica.smpp.pdu.SubmitSMResp;
import com.logica.smpp.pdu.Unbind;
import com.logica.smpp.pdu.UnbindResp;
import com.logica.smpp.pdu.WrongLengthOfStringException;
import com.logica.smpp.util.Queue;
*/
import org.smpp.Connection;

import org.smpp.Data;
import org.smpp.ServerPDUEvent;
import org.smpp.ServerPDUEventListener;
import org.smpp.Session;
import org.smpp.SmppObject;
import org.smpp.TCPIPConnection;
import org.smpp.pdu.Address;
import org.smpp.pdu.AddressRange;
import org.smpp.pdu.BindReceiver;
import org.smpp.pdu.BindRequest;
import org.smpp.pdu.BindResponse;
import org.smpp.pdu.BindTransciever;
import org.smpp.pdu.BindTransmitter;
import org.smpp.pdu.CancelSM;
import org.smpp.pdu.CancelSMResp;
import org.smpp.pdu.DataSM;
import org.smpp.pdu.DataSMResp;
import org.smpp.pdu.DeliverSM;
import org.smpp.pdu.DestinationAddress;
import org.smpp.pdu.EnquireLink;
import org.smpp.pdu.EnquireLinkResp;
import org.smpp.pdu.PDU;
import org.smpp.pdu.PDUHeader;
import org.smpp.pdu.QuerySM;
import org.smpp.pdu.QuerySMResp;
import org.smpp.pdu.ReplaceSM;
import org.smpp.pdu.ReplaceSMResp;
import org.smpp.pdu.Request;
import org.smpp.pdu.Response;
import org.smpp.pdu.SubmitMultiSM;
import org.smpp.pdu.SubmitMultiSMResp;
import org.smpp.pdu.SubmitSM;
import org.smpp.pdu.SubmitSMResp;
import org.smpp.pdu.Unbind;
import org.smpp.pdu.UnbindResp;
import org.smpp.pdu.WrongLengthOfStringException;
import org.smpp.util.Queue;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.vtl.smsc.exceptions.BusinessException;
import com.vtl.smsc.pojo.SmppConfig;
import com.vtl.smsc.util.ResponseConstants;
import com.vtl.smsc.util.spring.ThreadTaskExecutor;

public class SmscProcess
{
	   Connection connection;
	   private ThreadPoolTaskExecutor taskExecutor;
	   public static Logger logger = Logger.getLogger(SmscProcess.class);

	    /**
	     * File with default settings for the application.
	     */
	    //15-oct2015 static String propsFilePath = "/home/gprs/conf/smppchn.conf";

	    /**
	     * This is the SMPP session used for communication with SMSC.
	     */
	    public static Session session = null;

	    /**
	     * Contains the parameters and default values for this test
	     * application such as system id, password, default npi and ton
	     * of sender etc.
	     */
	    Properties properties = new Properties();

	    /**
	     * If the application is bound to the SMSC.
	     */
	    static boolean bound = false;

	    /**
	     * If the application has to keep reading commands
	     * from the keyboard and to do what's requested.
	     */
	    private boolean keepRunning = true;

	    /**
	     * Address of the SMSC.
	     */
	    String ipAddress = null;

	    /**
	     * The port number to bind to on the SMSC server.
	     */
	    int port = 0;

	    /**
	     * The name which identifies you to SMSC.
	     */
	    String systemId = null;

	    /**
	     * The password for authentication to SMSC.
	     */
	    String password = null;

	    /**
	     * How you want to bind to the SMSC: transmitter (t), receiver (r) or
	     * transciever (tr). Transciever can both send messages and receive
	     * messages. Note, that if you bind as receiver you can still receive
	     * responses to you requests (submissions).
	     */
	    String bindOption = "t";

	    /**
	     * Indicates that the Session has to be asynchronous.
	     * Asynchronous Session means that when submitting a Request to the SMSC
	     * the Session does not wait for a response. Instead the Session is provided
	     * with an instance of implementation of ServerPDUListener from the smpp
	     * library which receives all PDUs received from the SMSC. It's
	     * application responsibility to match the received Response with sended Requests.
	     */
	    boolean asynchronous = false;

	    /**
	     * This is an instance of listener which obtains all PDUs received from the SMSC.
	     * Application doesn't have explicitly call Session's receive() function,
	     * all PDUs are passed to this application callback object.
	     * See documentation in Session, Receiver and ServerPDUEventListener classes
	     * form the SMPP library.
	     */
	    SMPPTestPDUEventListener pduListener = null;

	    /**
	     * The range of addresses the smpp session will serve.
	     */
	    AddressRange addressRange = new AddressRange();

	    /*
	     * for information about these variables have a look in SMPP 3.4
	     * specification
	     */
	    String systemType = "";
	    String serviceType = "";
	    Address sourceAddress = new Address();
	    Address destAddress = new Address();
	    String scheduleDeliveryTime = "";
	    String validityPeriod = "";
	    String shortMessage = "";
	    int numberOfDestination = 1;
	    String messageId = "";
	    byte esmClass = 0;
	    byte protocolId = 0;
	    byte priorityFlag = 0;
	    byte registeredDelivery = 0;
	    byte replaceIfPresentFlag = 0;
	    byte dataCoding = 0;
	    byte smDefaultMsgId = 0;
	    private static SmscProcess instance = null;
	    /**
	     * If you attemt to receive message, how long will the application
	     * wait for data.
	     */
	    long receiveTimeout = Data.RECEIVE_BLOCKING;

	    /**
	     * Initialises the application, lods default values for
	     * connection to SMSC and for various PDU fields.
	     */
	     
	   
	   
	    static String propsFilePath="";
		public SmscProcess() throws IOException 
		{			
			
		}
		public  void SmscLoad(String props,SmppConfig smppConfig) throws BusinessException
		{
			try
			{
				propsFilePath=props;
				loadProperties(propsFilePath+"smppchn.conf",smppConfig);
			}			
			catch(Exception e)
			{
				logger.error(e.getMessage(), e);
				e.printStackTrace();
				throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
			}
		}

	    public static SmscProcess getInstance(int workerPool, int workerpoolBuffer) throws BusinessException {
	        if (instance == null)
	        {
	            try
	            {
	                instance = new SmscProcess();
	            } 
	            catch (IOException e)
	            {
	            	StringWriter stack = new StringWriter();
	    			PrintWriter writer = new PrintWriter(stack);
	    			e.printStackTrace(writer);
	                throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
	            }
	            catch (Exception e)
	            {
	            	StringWriter stack = new StringWriter();
	    			PrintWriter writer = new PrintWriter(stack);
	    			e.printStackTrace(writer);
	                logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
					+ ":"+stack.toString());
	                
	                throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);
	            }
	        } 
	        else
	        {
	        }
	        return instance;
	    }

	    /**
	     * Sets global SMPP library debug and event objects.
	     * Runs the application.
	     * @see com.logica.smpp.SmppObject#setDebug(Debug)
	     * @see com.logica.smpp.SmppObject#setEvent(Event)
	     */


	    /**
	     * Displays the menu and lets you choose from available options.
	     */


	    /**
	     * Ubinds (logs out) from the SMSC and closes the connection.
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.2 UNBIND Operation."
	     *
	     * @see Session#unbind()
	     * @see Unbind
	     * @see UnbindResp
	     */
	    public static void unbind() 
	    {
	        logger.info("SMPPTest.unbind()");
	        try {

	            if (!bound) {
	                logger.info("Not bound, cannot unbind.");
	                return;
	            }

	            // send the request
	            logger.info("Going to unbind.");
	            if (session.getReceiver().isReceiver()) 
	            {
	                logger.info("It can take a while to stop the receiver.");
	            }
	            UnbindResp response = session.unbind();
	            logger.info("Unbind response " + response.debugString());
	            bound = false;

	        } 
	        catch (Exception e)
	        {
	            logger.info("Unbind operation failed. " + e);
	            logger.info("Unbind operation failed. " + e);
	            
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
			    
	        }
	        finally
	        {
	            //debug.exit(this);
	        }
	    }

	    /**
	     * Creates a new instance of <code>SubmitSM</code> class, lets you set
	     * subset of fields of it. This PDU is used to send SMS message
	     * to a device.
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.4 SUBMIT_SM Operation."
	     *
	     * @see Session#submit(SubmitSM)
	     * @see SubmitSM
	     * @see SubmitSMResp
	     */
	    public synchronized String submit(String msisdn, String message,String sourceaddr) 
	    {
	        logger.info("SmscProcess.submit()");
	        String responsesms = "";
	        try {
	            SubmitSM request = new SubmitSM();
	            SubmitSMResp response;

	            // input values
	            serviceType = getParam("Service type", serviceType);
	            sourceAddress = getAddress("Source", sourceAddress);
	            logger.info("sourceAddress = " + sourceAddress);
	            destAddress = getAddress("Destination", destAddress);
	            destAddress.setAddress(msisdn);
	            sourceAddress.setAddress(sourceaddr);

	            
	            logger.info("Dest addresss"+destAddress.getAddress());
	            logger.info("source addresss"+sourceAddress.getAddress());

	            replaceIfPresentFlag = getParam("Replace if present flag", replaceIfPresentFlag);
	            shortMessage = getParam("The short message", message);
	            scheduleDeliveryTime = getParam("Schedule delivery time", scheduleDeliveryTime);
	            validityPeriod = getParam("Validity period", validityPeriod);
	            esmClass = getParam("Esm class", esmClass);
	            protocolId = getParam("Protocol id", protocolId);
	            priorityFlag = getParam("Priority flag", priorityFlag);
	            registeredDelivery = getParam("Registered delivery", registeredDelivery);
	            dataCoding = getParam("Data encoding", dataCoding);
	            smDefaultMsgId = getParam("Sm default msg id", smDefaultMsgId);

	            // set values
	            request.setServiceType(serviceType);
	            request.setSourceAddr(sourceAddress);
	            request.setDestAddr(destAddress);
	            request.setReplaceIfPresentFlag(replaceIfPresentFlag);
	            request.setShortMessage(message);
	            request.setScheduleDeliveryTime(scheduleDeliveryTime);
	            request.setValidityPeriod(validityPeriod);
	            request.setEsmClass(esmClass);
	            request.setProtocolId(protocolId);
	            request.setPriorityFlag(priorityFlag);
	            request.setRegisteredDelivery(registeredDelivery);
	            request.setDataCoding(dataCoding);
	            request.setSmDefaultMsgId(smDefaultMsgId);

	            // send the request

	            int count = 1;
	            count = getParam("How many times to submit this message (load test)",
	                    count);
	            for (int i = 0; i < count; i++) 
	            {
	                request.assignSequenceNumber(true);
	                logger.info("#" + i + "  ");
	                logger.info("Submit request ");
	                if (asynchronous) 
	                {
	                    response = session.submit(request);

	                    responsesms = "0";
	                   logger.info("inside asynchronus responsesms"+responsesms);

	                }
	                else
	                {
	                    response = session.submit(request);
	                    logger.info("Submit response " + response.debugString());
	                    responsesms = "0";
	                    messageId = response.getMessageId();


	                }
	                
	                logger.info("Response Status" + responsesms);
	            }

	        } 
	        catch (Exception e)
	        {
	            logger.info("Submit operation failed. " + e);
	            logger.info("Submit operation failed. " + e);
	            
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
			                
	        } 
	        finally
	        {
	            return responsesms;
	        }
	    }


	    /**
	     * Creates a new instance of <code>SubmitMultiSM</code> class, lets you set
	     * subset of fields of it. This PDU is used to send SMS message
	     * to multiple devices.
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.5 SUBMIT_MULTI Operation."
	     *
	     * @see Session#submitMulti(SubmitMultiSM)
	     * @see SubmitMultiSM
	     * @see SubmitMultiSMResp
	     */
	    private void submitMulti() {
	        logger.info("SmscProcess.submitMulti()");

	        try {
	            SubmitMultiSM request = new SubmitMultiSM();
	            SubmitMultiSMResp response;

	            // input values and set some :-)
	            serviceType = getParam("Service type", serviceType);
	            sourceAddress = getAddress("Source", sourceAddress);
	            numberOfDestination = getParam("Number of destinations", numberOfDestination);
	            for (int i = 0; i < numberOfDestination; i++) {
	                request.addDestAddress(new DestinationAddress(getAddress("Destination", destAddress)));
	            }
	            replaceIfPresentFlag = getParam("Replace if present flag", replaceIfPresentFlag);
	            shortMessage = getParam("The short message", shortMessage);
	            scheduleDeliveryTime = getParam("Schdule delivery time", scheduleDeliveryTime);
	            validityPeriod = getParam("Validity period", validityPeriod);
	            esmClass = getParam("Esm class", esmClass);
	            protocolId = getParam("Protocol id", protocolId);
	            priorityFlag = getParam("Priority flag", priorityFlag);
	            registeredDelivery = getParam("Registered delivery", registeredDelivery);
	            dataCoding = getParam("Data encoding", dataCoding);
	            smDefaultMsgId = getParam("Sm default msg id", smDefaultMsgId);

	            // set other values
	            request.setServiceType(serviceType);
	            request.setSourceAddr(sourceAddress);
	            request.setReplaceIfPresentFlag(replaceIfPresentFlag);
	            request.setShortMessage(shortMessage);
	            request.setScheduleDeliveryTime(scheduleDeliveryTime);
	            request.setValidityPeriod(validityPeriod);
	            request.setEsmClass(esmClass);
	            request.setProtocolId(protocolId);
	            request.setPriorityFlag(priorityFlag);
	            request.setRegisteredDelivery(registeredDelivery);
	            request.setDataCoding(dataCoding);
	            request.setSmDefaultMsgId(smDefaultMsgId);

	            // send the request
	            logger.info("Submit Multi request " + request.debugString());
	            if (asynchronous)
	            {
	                session.submitMulti(request);
	            }
	            else 
	            {
	                response = session.submitMulti(request);
	                logger.info("Submit Multi response " + response.debugString());
	                messageId = response.getMessageId();
	            }

	        }
	        catch (Exception e) 
	        {
	            logger.info("Submit Multi operation failed. " + e);
	            logger.info("Submit Multi operation failed. " + e);
	           
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
			    
	        
	        }
	        finally 
	        {

	        }
	    }

	    /**
	     * Creates a new instance of <code>ReplaceSM</code> class, lets you set
	     * subset of fields of it. This PDU is used to replace certain
	     * attributes of already submitted message providing that you 'remember'
	     * message id of the submitted message. The message id is assigned
	     * by SMSC and is returned to you with the response to the submision
	     * PDU (SubmitSM, DataSM etc.).
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.10 REPLACE_SM Operation."
	     *
	     * @see Session#replace(ReplaceSM)
	     * @see ReplaceSM
	     * @see ReplaceSMResp
	     */
	    private void replace()
	    {
	        logger.info("SmscProcess.replace()");
	        try 
	        {
	            ReplaceSM request = new ReplaceSM();
	            ReplaceSMResp response;

	            // input values
	            messageId = getParam("Message id", messageId);
	            sourceAddress = getAddress("Source", sourceAddress);
	            shortMessage = getParam("The short message", shortMessage);
	            scheduleDeliveryTime = getParam("Schedule delivery time", scheduleDeliveryTime);
	            validityPeriod = getParam("Validity period", validityPeriod);
	            registeredDelivery = getParam("Registered delivery", registeredDelivery);
	            smDefaultMsgId = getParam("Sm default msg id", smDefaultMsgId);

	            // set values
	            request.setMessageId(messageId);
	            request.setSourceAddr(sourceAddress);
	            request.setShortMessage(shortMessage);
	            request.setScheduleDeliveryTime(scheduleDeliveryTime);
	            request.setValidityPeriod(validityPeriod);
	            request.setRegisteredDelivery(registeredDelivery);
	            request.setSmDefaultMsgId(smDefaultMsgId);

	            // send the request
	            logger.info("Replace request " + request.debugString());
	            if (asynchronous) {
	                session.replace(request);
	            } else {
	                response = session.replace(request);
	                logger.info("Replace response " + response.debugString());
	            }

	        } 
	        catch (Exception e)
	        {
	            logger.info("Replace operation failed. " + e);
	            logger.info("Replace operation failed. " + e);
	            
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        }
	        finally 
	        {
	        }
	    }

	    /**
	     * Creates a new instance of <code>CancelSM</code> class, lets you set
	     * subset of fields of it. This PDU is used to cancel an already
	     * submitted message. You can only cancel a message which haven't been
	     * delivered to the device yet.
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.9 CANCEL_SM Operation."
	     *
	     * @see Session#cancel(CancelSM)
	     * @see CancelSM
	     * @see CancelSMResp
	     */
	    private void cancel() 
	    {
	        logger.info("SMPPTest.cancel()");
	        try
	        {
	            CancelSM request = new CancelSM();
	            CancelSMResp response;

	            // input values
	            serviceType = getParam("Service type", serviceType);
	            messageId = getParam("Message id", messageId);
	            sourceAddress = getAddress("Source", sourceAddress);
	            destAddress = getAddress("Destination", destAddress);

	            // set values
	            request.setServiceType(serviceType);
	            request.setMessageId(messageId);
	            request.setSourceAddr(sourceAddress);
	            request.setDestAddr(destAddress);

	            // send the request
	            logger.info("Cancel request " + request.debugString());
	            if (asynchronous)
	            {
	                session.cancel(request);
	            }
	            else
	            {
	                response = session.cancel(request);
	                logger.info("Cancel response " + response.debugString());
	            }

	        } 
	        catch (Exception e) 
	        {
	            logger.info("Cancel operation failed. " + e);
	            logger.info("Cancel operation failed. " + e);
	        
	        
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        }
	        finally
	        {
	            //debug.exit(this);
	        }
	    }

	    /**
	     * Creates a new instance of <code>DataSM</code> class, lets you set
	     * subset of fields of it. This PDU is an alternative to the <code>SubmitSM</code>
	     * and </code>DeliverSM</code>. It delivers the data to the specified device.
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.7 DATA_SM Operation."
	     *
	     * @see Session#data(DataSM)
	     * @see DataSM
	     * @see DataSMResp
	     */
	    private void data()
	    {
	        logger.info("SMPPTest.data()");

	        try
	        {
	            DataSM request = new DataSM();
	            DataSMResp response;

	            // input values
	            serviceType = getParam("Service type", serviceType);
	            sourceAddress = getAddress("Source", sourceAddress, Data.SM_DATA_ADDR_LEN);
	            destAddress = getAddress("Destination", destAddress, Data.SM_DATA_ADDR_LEN);
	            esmClass = getParam("Esm class", esmClass);
	            registeredDelivery = getParam("Registered delivery", registeredDelivery);
	            dataCoding = getParam("Data encoding", dataCoding);

	            // set values
	            request.setServiceType(serviceType);
	            request.setSourceAddr(sourceAddress);
	            request.setDestAddr(destAddress);
	            request.setEsmClass(esmClass);
	            request.setRegisteredDelivery(registeredDelivery);
	            request.setDataCoding(dataCoding);

	            // send the request
	            logger.info("Data request " + request.debugString());
	            if (asynchronous)
	            {
	                session.data(request);
	            }
	            else
	            {
	                response = session.data(request);
	                logger.info("Data response " + response.debugString());
	                messageId = response.getMessageId();
	            }

	        } 
	        catch (Exception e)
	        {
	            logger.info("Data operation failed. " + e);
	            logger.info("Data operation failed. " + e);
	            
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        } 
	        finally
	        {
	            //debug.exit(this);
	        }
	    }

	    /**
	     * Creates a new instance of <code>QuerySM</code> class, lets you set
	     * subset of fields of it. This PDU is used to fetch information
	     * about status of already submitted message providing that you 'remember'
	     * message id of the submitted message. The message id is assigned
	     * by SMSC and is returned to you with the response to the submision
	     * PDU (SubmitSM, DataSM etc.).
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.8 QUERY_SM Operation."
	     *
	     * @see Session#query(QuerySM)
	     * @see QuerySM
	     * @see QuerySMResp
	     */
	    public void query()
	    {
	        logger.info("SMPPTest.query()");
	        try
	        {
	            QuerySM request = new QuerySM();
	            QuerySMResp response;

	            // input values
	            messageId = getParam("Message id", messageId);
	            sourceAddress = getAddress("Source", sourceAddress);

	            // set values
	            request.setMessageId(messageId);
	            request.setSourceAddr(sourceAddress);

	            // send the request
	            logger.info("Query request " + request.debugString());
	            if (asynchronous) 
	            {
	                session.query(request);
	            }
	            else
	            {
	                response = session.query(request);
	                logger.info("Query response " + response.debugString());
	                messageId = response.getMessageId();
	            }

	        } 
	        catch (Exception e)
	        {
	            logger.info("Query operation failed. " + e);
	            logger.info("Query operation failed. " + e);
	        
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        } 
	        finally
	        {
	        }
	    }

	    /**
	     * Creates a new instance of <code>EnquireSM</code> class.
	     * This PDU is used to check that application level of the other party
	     * is alive. It can be sent both by SMSC and ESME.
	     * <p/>
	     * See "SMPP Protocol Specification 3.4, 4.11 ENQUIRE_LINK Operation."
	     *
	     * @see Session#enquireLink(EnquireLink)
	     * @see EnquireLink
	     * @see EnquireLinkResp
	     */
	    public boolean enquireLink() 
	    {
	        boolean link = false;

	        logger.info("SMPP.enquireLink()");
	        try
	        {
	            EnquireLink request = new EnquireLink();
	            EnquireLinkResp response;
	            logger.info("Enquire Link request " + request.debugString());
	            if (asynchronous)
	            {
	                response = session.enquireLink(request);
	                link = true;
	            } 
	            else 
	            {
	                response = session.enquireLink(request);
	                logger.info("Enquire Link response " + response.debugString());
	                link = true;
	            }

	        } 
	        catch (Exception e)
	        {
	            link = false;
	            logger.info("Enquire Link operation failed. " + e);
	        
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        } 
	        finally
	        {
	            //debug.exit(this);
	        }
	        return link;
	    }

	    public boolean enquireLink(int sleeptime)
	    {
	        boolean link = false;

	        logger.info("SMPP.enquireLink()");
	        try
	        {
	            Thread.currentThread().sleep(sleeptime);
	            EnquireLink request = new EnquireLink();
	            EnquireLinkResp response;
	            logger.info("Enquire Link request " + request.debugString());
	            if (asynchronous)
	            {
	                response = session.enquireLink(request);
	                link = true;
	            }
	            else 
	            {
	                response = session.enquireLink(request);
	                logger.info("Enquire Link response " + response.debugString());
	                link = true;
	            }

	        } 
	        
	        catch (Exception e) 
	        {
	            link =false;
	        } 
	        finally 
	        {
	            //debug.exit(this);
	        }
	        return link;
	    }

	    /**
	     * Receives one PDU of any type from SMSC and prints it on the screen.
	     *
	     * @see Session#receive()
	     * @see Response
	     * @see com.logica.smpp.ServerPDUEvent
	     */
	    public void receive()
	    {
	        logger.info("SMPPTest.receive()");
	        try
	        {

	            PDU pdu = null;
	            logger.info("Going to receive a PDU. ");
	            if (receiveTimeout == Data.RECEIVE_BLOCKING)
	            {
	                logger.info("The receive is blocking, i.e. the application " +
	                        "will stop until a PDU will be received.");
	            } 
	            else
	            {
	                logger.info("The receive timeout is " + receiveTimeout / 1000 + " sec.");
	            }
	            if (asynchronous)
	            {
	                ServerPDUEvent pduEvent =
	                        pduListener.getRequestEvent(receiveTimeout);
	            }
	            else
	            {

	                pdu = session.receive(receiveTimeout);
	            }
	            if (pdu != null)
	            {
	                logger.info("Received PDU " + pdu.debugString());
	                if (pdu.isRequest())
	                {
	                    Response response = ((Request) pdu).getResponse();
	                    // respond with default response
	                    logger.info("Going to send default response to request " + response.debugString());
	                    session.respond(response);
	                }
	            } 
	            else
	            {
	                logger.info("No PDU received this time.");
	            }

	        } 
	        catch (Exception e)
	        {
	            logger.info("Receiving failed. " + e);
	            logger.info("Receiving failed. " + e);
	        
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        }
	        finally
	        {
	            //debug.exit(this);
	        }
	    }

	    /**
	     * If bound, unbinds and then exits this application.
	     */
	    private void exit()
	    {
	        logger.info("SMPPTest.exit()");
	        if (bound)
	        {
	            unbind();
	        }
	        keepRunning = false;
	    }


	    /**
	     * Implements simple PDU listener which handles PDUs received from SMSC.
	     * It puts the received requests into a queue and discards all received
	     * responses. Requests then can be fetched (should be) from the queue by
	     * calling to the method <code>getRequestEvent</code>.
	     *
	     * @see com.logica.smpp.util.Queue
	     * @see ServerPDUEvent
	     * @see com.logica.smpp.ServerPDUEventListener
	     * @see com.logica.smpp.SmppObject
	     */
	    private class SMPPTestPDUEventListener
	            extends SmppObject
	            implements ServerPDUEventListener 
	      {
	        Session session;
	        Queue requestEvents = new Queue();

	        public SMPPTestPDUEventListener(Session session)
	        {
	            this.session = session;
	        }

	        public void handleEvent(ServerPDUEvent event)
	        {
	            PDU pdu = event.getPDU();
	            if (pdu.isRequest())
	            {
	                logger.info("async request received, enqueuing " + pdu.debugString());
	                String str=pdu.debugString();


	            try{
	                    String msgRec = new String(pdu.getBody().getBuffer()).trim();
	                    //com.logica.smpp.pdu.Response response = ((Request) pdu).getResponse();
	                    org.smpp.pdu.Response response = ((Request) pdu).getResponse();
	                    DeliverSM ds = ((DeliverSM) pdu);
	                    String sourceno = ds.getSourceAddr().getAddress();
	                    String shortmessage = ds.getShortMessage();

	                    logger.info("shortmessage = " + shortmessage);        
	                    logger.info("Source Number:" + sourceno);
	                    
	                    
	                }
	            	catch(Exception e)
	                {
	            		
	            		logger.info("Error in handleEvent(ServerPDUEvent event)-> " + e);
	            		
	            		StringWriter stack = new StringWriter();
	    				PrintWriter writer = new PrintWriter(stack);
	    				e.printStackTrace(writer);
	    				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
	    				+ ":"+stack.toString());

	                }
	                

	               
	                synchronized (requestEvents)
	                {
	                    requestEvents.enqueue(event);
	                    requestEvents.notify();
	                }
	            } 
	            else if (pdu.isResponse())
	            {
	                logger.info("async response received " +
	                        pdu.debugString());
	            }
	            else
	            {
	                logger.info("pdu of unknown class (not request nor " +"response) received, discarding " +pdu.debugString());
	            }
	        }

	        /**
	         * Returns received pdu from the queue. If the queue is empty,
	         * the method blocks for the specified timeout.
	         */
	        public ServerPDUEvent getRequestEvent(long timeout)
	        {
	            ServerPDUEvent pduEvent = null;
	            synchronized (requestEvents)
	            {
	                if (requestEvents.isEmpty()) 
	                {
	                    try
	                    {
	                        requestEvents.wait(timeout);
	                    }
	                    catch (InterruptedException e)
	                    {
	                        // ignoring, actually this is what we're waiting for
	                    }
	                }
	                if (!requestEvents.isEmpty()) 
	                {
	                    pduEvent = (ServerPDUEvent) requestEvents.dequeue();
	                }
	            }
	            return pduEvent;
	        }
	    }

	    /**
	     * Prompts the user to enter a string value for a parameter.
	     */
	    private String getParam(String prompt, String defaultValue) {
	        String value = "";
	        String promptFull = prompt;
	        promptFull += defaultValue == null ? "" : " [" + defaultValue + "] ";
	        logger.info(promptFull);
	        return defaultValue;
	    }

	    /**
	     * Prompts the user to enter a byte value for a parameter.
	     */
	    private byte getParam(String prompt, byte defaultValue) {
	        return Byte.parseByte(getParam(prompt, Byte.toString(defaultValue)));
	    }

	    /**
	     * Prompts the user to enter an integer value for a parameter.
	     */
	    private int getParam(String prompt, int defaultValue) {
	        return Integer.parseInt(getParam(prompt, Integer.toString(defaultValue)));
	    }

	    /**
	     * Prompts the user to enter an address value with specified max length.
	     */
	    private Address getAddress(String type, Address address, int maxAddressLength)
	            throws WrongLengthOfStringException {
	        byte ton = getParam(type + " address TON", address.getTon());
	        byte npi = getParam(type + " address NPI", address.getNpi());
	        String addr = getParam(type + " address", address.getAddress());
	        address.setTon(ton);
	        address.setNpi(npi);
	        address.setAddress(addr, maxAddressLength);
	        return address;
	    }

	    /**
	     * Prompts the user to enter an address value with max length set to the
	     * default length Data.SM_ADDR_LEN.
	     */
	    private Address getAddress(String type, Address address)
	            throws WrongLengthOfStringException {
	        return getAddress(type, address, Data.SM_ADDR_LEN);
	    }

	    /**
	     * Loads configuration parameters from the file with the given name.
	     * Sets private variable to the loaded values.
	     */
	    private void loadProperties(String fileName,SmppConfig smppConfig)
	    		throws BusinessException
	    		{
	    	
	    	try
	    	{
	    		logger.info("Reading configuration file " + fileName + "...\n\n");
	    		FileInputStream propsFile = new FileInputStream(fileName);
	    		properties.load(propsFile);
	    		propsFile.close();
	    		byte ton;
	    		byte npi;
	    		String addr;
	    		String bindMode;
	    		int rcvTimeout;
	    		String syncMode;
	     
	    		ipAddress = properties.getProperty("ip-address");
	    		port = getIntProperty("port", port);
	    		systemId = properties.getProperty("system-id");
	    		password = properties.getProperty("password");

	    		ton = getByteProperty("addr-ton", addressRange.getTon());
	    		npi = getByteProperty("addr-npi", addressRange.getNpi());
	    		addr = properties.getProperty("address-range",
	            addressRange.getAddressRange());
		        addressRange.setTon(ton);
		        addressRange.setNpi(npi);
		        try
		        {
		            	addressRange.setAddressRange(addr);
		        } 
		        catch (WrongLengthOfStringException e)
		        {
		            logger.info("The length of address-range parameter is wrong.");
		        }


		        ton = getByteProperty("source-ton", sourceAddress.getTon());
		        npi = getByteProperty("source-npi", sourceAddress.getNpi());
		        addr = properties.getProperty("source-address",
		                sourceAddress.getAddress());
		        setAddressParameter("source-address", sourceAddress, ton, npi, addr);
		        ton = getByteProperty("destination-ton", destAddress.getTon());
		        npi = getByteProperty("destination-npi", destAddress.getNpi());
		        addr = properties.getProperty("destination-address",
		                destAddress.getAddress());
		        setAddressParameter("destination-address", destAddress, ton, npi, addr);
		        serviceType = properties.getProperty("service-type", serviceType);
		        systemType = properties.getProperty("system-type", systemType);
		        bindMode = properties.getProperty("bind-mode", bindOption);
		        if (bindMode.equalsIgnoreCase("transmitter")) 
		        {
		            bindMode = "t";
		        }
		        else if (bindMode.equalsIgnoreCase("receiver"))
		        {
		            bindMode = "r";
		        }
		        else if (bindMode.equalsIgnoreCase("transciever"))
		        {
		            bindMode = "tr";
		        }
		        else if (!bindMode.equalsIgnoreCase("t") &&
		                !bindMode.equalsIgnoreCase("r") &&
		                !bindMode.equalsIgnoreCase("tr"))
		        {
		            logger.info("The value of bind-mode parameter in " +
		                    "the configuration file " + fileName + " is wrong. " +
		                    "Setting the default");
		            bindMode = "t";
		        }
		        bindOption = bindMode;
		        dataCoding = getByteProperty("datacoding", dataCoding);
		        esmClass = getByteProperty("esmclass", esmClass);
	
		        // receive timeout in the cfg file is in seconds, we need milliseconds
		        // also conversion from -1 which indicates infinite blocking
		        // in the cfg file to Data.RECEIVE_BLOCKING which indicates infinite
		        // blocking in the library is needed.
		        if (receiveTimeout == Data.RECEIVE_BLOCKING) 
		        {
		            rcvTimeout = -1;
		        } else {
		            rcvTimeout = ((int) receiveTimeout) / 1000;
		        }
		        rcvTimeout = getIntProperty("receive-timeout", rcvTimeout);
		        if (rcvTimeout == -1)
		        {
		            receiveTimeout = Data.RECEIVE_BLOCKING;
		        } 
		        else 
		        {
		            receiveTimeout = rcvTimeout * 1000;
		        }
		        
		        syncMode = properties.getProperty("sync-mode", (asynchronous ? "async" : "sync"));
		        if (syncMode.equalsIgnoreCase("sync"))
		        {
		            asynchronous = false;
		        } 
		        else if (syncMode.equalsIgnoreCase("async"))
		        {
		            asynchronous = true;
		        }
		        else {
		            asynchronous = false;
		        }
		        //---------------------
		        getInstance(smppConfig.getPool(),smppConfig.getPoolbuffer());
		        bind();
				//-----------------
	    	}//End of try
	    	catch(FileNotFoundException e)
	    	{
	    		StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());

	    		throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);	    		
	    	}
	    	catch(IOException e)
	    	{
	    		StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());

	    		throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);	    		
	    	}
	    	catch(Exception e)
	    	{
	    		StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());

	    		throw new BusinessException(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode(),ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg(), e);	    		
	    	}
	    	

	    }

	    /**
	     * Gets a property and converts it into byte.
	     */
	    private byte getByteProperty(String propName, byte defaultValue) {
	        return Byte.parseByte(properties.getProperty(propName, Byte.toString(defaultValue)));
	    }

	    /**
	     * Gets a property and converts it into integer.
	     */
	    private int getIntProperty(String propName, int defaultValue) {
	        return Integer.parseInt(properties.getProperty(propName, Integer.toString(defaultValue)));
	    }

	    /**
	     * Sets attributes of <code>Address</code> to the provided values.
	     */
	    private void setAddressParameter(String descr, Address address, byte ton, byte npi, String addr)
	    {
	        address.setTon(ton);
	        address.setNpi(npi);
	        try
	        {
	            address.setAddress(addr);
	        } 
	        catch (WrongLengthOfStringException e)
	        {
	            logger.info("The length of " + descr + " parameter is wrong.");
	        }
	    }

	    public void bind() 
	    {
	        logger.info("--------------------------------------------------------------------------------");
	        logger.info("Start SmscProcess.bind()");
	        
	        
	        try {

	            if (bound) 
	            {
	                logger.info("Already bound, unbind first.");
	                return;
	            }
	            logger.info("Default Parameters........");
	            BindRequest request = null;
	            BindResponse response = null;
	            String syncMode = (asynchronous ? "a" : "s");

	            // type of the session
	            syncMode = getParam("Asynchronous/Synchronnous Session? (a/s)",
	                    syncMode);
	            if (syncMode.compareToIgnoreCase("a") == 0)
	            {
	                asynchronous = true;
	            }
	            else if (syncMode.compareToIgnoreCase("s") == 0) 
	            {
	                asynchronous = false;
	            }
	            else
	            {
	                logger.info("Invalid mode async/sync, expected a or s, got "
	                        + syncMode + ". Operation canceled.");
	                return;
	            }

	            // input values
	            bindOption = getParam("Transmitter/Receiver/Transciever (t/r/tr)",
	                    bindOption);

	            if (bindOption.compareToIgnoreCase("t") == 0)
	            {
	                request = new BindTransmitter();
	            }
	            else if (bindOption.compareToIgnoreCase("r") == 0)
	            {
	                request = new BindReceiver();
	            }
	            else if (bindOption.compareToIgnoreCase("tr") == 0)
	            {
	                request = new BindTransciever();
	            }
	            else
	            {
	                logger.info("Invalid bind mode, expected t, r or tr, got " +
	                        bindOption + ". Operation canceled.");
	                return;
	            }

	            
	            ipAddress = getParam("IP address of SMSC", ipAddress);
	            port = getParam("Port number", port);

	            connection = new TCPIPConnection(ipAddress, port);
	            connection.setReceiveTimeout(20 * 1000);

	            session = new Session(connection);

	            systemId = getParam("Your system ID", systemId);
	            password = getParam("Your password", password);

	            // set values
	            request.setSystemId(systemId);
	            request.setPassword(password);
	            request.setSystemType(systemType);
	            request.setInterfaceVersion((byte) 0x34);
	            request.setAddressRange(addressRange);

	            // send the request
	            logger.info("Bind request " + request.debugString());
	            logger.info("Bind request " + request.debugString());
	            if (asynchronous)
	            {
	                pduListener = new SMPPTestPDUEventListener(session);
	                response = session.bind(request, pduListener);
	            }
	            else
	            {
	                response = session.bind(request);
	            }
	            logger.info("Bind response " + response.debugString());
	            logger.info("Bind response " + response.debugString());
	            if (response.getCommandStatus() == Data.ESME_ROK) {
	                bound = true;
	            }

	        } catch (Exception e) 
	        {
	            logger.info("Bind operation failed. " + e);
	            logger.info("Bind operation failed. " + e);
	        
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        
	        } 
	        finally
	        {

	            logger.info("END SmscProcess.bind()");
	            logger.info("--------------------------------------------------------------------------------");
	        }
	    }

		public boolean receive(SmppConfig cfg)
	    {

	        boolean result = false;


	        try {
	            PDU pdu = null;
	            PDUHeader ph = null;
	            
	            if (receiveTimeout == -1L) {
	                logger.info("The receive is blocking, i.e. the application will stop " +
	                        "until a PDU will be received.");
	            } else {
	            }
	             
	            if (asynchronous)
	            {
	                ServerPDUEvent pduEvent = pduListener.getRequestEvent(receiveTimeout);
	               
	                //*************THREAD*******************
	               //System.out.println("[ SmscProcess()--> ]");	              
	               //ThreadTaskExecutor.getPool().execute(new SMPPThread(pduEvent, cfg));
	                taskExecutor.execute(new SMPPThread(pduEvent, cfg));
	              
	            } 
	            else
	            {
	                if( session !=null )
	                pdu = session.receive(receiveTimeout);
	            }
	        }
	        catch (Exception e)
	        {
	            logger.error("Receiving failed. " + e.getMessage(), e);
	            logger.error("Receiving failed. " + e.getMessage(), e);
	            
	            StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());

	        }
	        finally 
	        {
	            return result;
	        }
	    }

	    public void kill() 
	    {
	        try 
	        {

	            if (session != null)
	            {
	                if (session.isBound()) {
	                    if (connection != null)
	                    {
	                        connection = null;
	                        try
	                        {
	                        connection.close();
	                        }catch( Exception e){}
	                    }

	                    session = null;
	                    bound = false;
	                }
	            }
	            else
	            {
	                if (connection != null)
	                    connection.close();
	            }

	        } catch (IOException e)
	        {
	            
				StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
    
	        }

	    }

	    public void checkPDU()
	    {
	        try
	        {
	            
	            PDU pdu = null;
	            //while (true) {
	            
	            
	            logger.info("Session: " + session.getState());
	                
	                if (session.getState() == 15) 
	                {
	                	
	                	logger.info("**** Enquire link Request *****");
	                }
	                if (session.getState() == 16)
	                {
	                	
	                	logger.info("**** Enquire link Response *****");
	                }
	               

	                if (asynchronous)
	                {
	                    ServerPDUEvent pduEvent =
	                            pduListener.getRequestEvent(receiveTimeout);
	                    if (pduEvent != null)
	                    {
	                        pdu = pduEvent.getPDU();
	                    }
	                } 
	                else
	                {
	                    if(session != null)
	                    pdu = session.receive(receiveTimeout);
	                }
	                if (pdu != null)
	                {
	                    logger.info("Received PDU " + pdu.debugString());
	                    if (pdu.isRequest())
	                    {
	                        Response response = ((Request) pdu).getResponse();

	                        // respond with default response
	                        logger.info("Going to send default response to request " + response.debugString());
	                        session.respond(response);
	                    }
	                    logger.info("******************************************************");
	                    if (pdu.getCommandId() == 15) 
	                    {
	                        Response response = ((Request) pdu).getResponse();
	                        session.respond(response);
	                        logger.info("Enquire Link response to SMSC " + response.debugString());
	                    }
	                    logger.info("PDU ID :" + pdu.getCommandId());
	                    logger.info("PDU Length" + pdu.getCommandLength());
	                    logger.info("PDU Status" + pdu.getCommandStatus());
	                    logger.info("******************************************************");

	                } else 
	                {
	                    logger.info("No PDU received this time.");
	                }
	          //  }
	        } 
	        catch (Exception e)
	        {
	        	StringWriter stack = new StringWriter();
				PrintWriter writer = new PrintWriter(stack);
				e.printStackTrace(writer);
				logger.error(ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseCode()+ ":"+ ResponseConstants.ERR_SYSTEM_EXCEPTION.getResponseMsg()
				+ ":"+stack.toString());
	        }
	    }//End of checkPDU()
		public ThreadPoolTaskExecutor getTaskExecutor() {
			return taskExecutor;
		}
		public void setTaskExecutor(ThreadPoolTaskExecutor taskExecutor) {
			this.taskExecutor = taskExecutor;
		}

	}

