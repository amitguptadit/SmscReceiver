package com.vtl.smsc.service.impl;

import com.vtl.smsc.exceptions.BusinessException;
import com.vtl.smsc.pojo.SmppConfig;

public interface SmscReceiverImpl 
{
		
	public  void initBean() throws BusinessException;
	public  SmppConfig loadSmppCong() throws BusinessException;
}
