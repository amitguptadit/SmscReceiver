package com.vtl.smsc.util;
import java.text.SimpleDateFormat;
/*
 * @author @mit.gupta
 * @version 1.0
 */
public interface DPVConstants
{
	
	String SEPERATOR_COMMA = ",";
	SimpleDateFormat SDF_LONG_FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");
	Integer MSISDN_LENGTH = 12;
	String IN_MIDDLEWARE_RESPONSE_CODE = "0";
	String DPV_BASE_MASTER_CACHE = "DPV-BASE-MASTER-CACHE";

	String PARAM_USE_CACHE_NAME = "USE_CACHE";

	String VALUE_TRUE = "true";

	String PROCESS_TYPE_IN = "IN";
	String PROCESS_TYPE_SMS = "SMS";
	Integer BATCH_SIZE = 3;
	String DPV_TRUNCATE_STMT = "TRUNCATE TABLE PV_RECHARGE_BASE";
	
	String PV_TYPE_ACCUMULATION = "ACCUMULATION";
	String PV_TYPE_EVENT = "EVENT";
	
	String MSG_SUCCESS = "S";
	String MSG_FAIL = "F";
	String ACCUMULATION_ACTIVE = "A";
	String ACCUMULATION_CLOSE = "C";
	String DATE_FORMAT="yyyy-MM-dd HH:mm:ss";
	
}

