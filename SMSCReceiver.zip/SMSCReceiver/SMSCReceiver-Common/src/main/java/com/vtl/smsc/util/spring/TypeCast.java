package com.vtl.smsc.util.spring;

/**
 * Utility cast to separate unsafe type cast from other code that requires warning-free
 * compiles.
 */
/**
 * @author @mit.gupta
 * @version 1.0
 */
public final class TypeCast {

    @SuppressWarnings("unchecked")
    public static <T> T cast(Object obj) {
        return (T) obj; // unchecked cast: OK
    }

    private TypeCast() {
        // prevent instantiation
    }
}