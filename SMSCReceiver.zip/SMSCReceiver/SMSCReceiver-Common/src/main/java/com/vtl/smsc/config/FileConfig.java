package com.vtl.smsc.config;
/**
 * @author @mit.gupta
 * @version 1.0
 */
public class FileConfig
{

	
	private String localFilePath;
	
	
	public String getLocalFilePath() {
		return localFilePath;
	}

	public void setLocalFilePath(String localFilePath) {
		this.localFilePath = localFilePath;
	}

	

}