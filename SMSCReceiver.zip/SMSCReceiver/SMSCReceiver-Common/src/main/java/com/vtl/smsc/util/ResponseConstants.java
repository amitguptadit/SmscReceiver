package com.vtl.smsc.util;

/**
 * @author @mit.gupta
 * @version 1.0
 */

public enum ResponseConstants
{
	SUCCESS_MESSAGE("SVC000", "SUCCESSFULL"),
	ERR_SYSTEM_EXCEPTION("SVC001","Exception while process request, Kindly contact administrator"),
	ERR_DIRECTORY_NOT_EXIST("SVC002","The following directory does not exist : "),
	ERR_ATTACH_OFFER("SVC003","The offer can not be attached this time, Please try again"),;

	private final String responseCode;
	private final String responseMsg;

	private ResponseConstants(String responseCode, String responseMsg) {
		this.responseCode = responseCode;
		this.responseMsg = responseMsg;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

}
